﻿Public MustInherit Class ActionResult
    Public MustOverride Sub ExecuteResult(ByVal context As CommandContext)
End Class
