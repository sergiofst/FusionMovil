﻿Public Interface ICommandFactory
    Sub ReleaseCommand(ByVal command As ICommand)
    Function CreateController(ByVal requestContext As Routing.RequestContext, ByVal controllerName As String) As ICommand
End Interface
