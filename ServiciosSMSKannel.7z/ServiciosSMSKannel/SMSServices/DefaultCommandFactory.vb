﻿Public Class DefaultCommandFactory
    Implements ICommandFactory


    Public Function CreateController(ByVal requestContext As System.Web.Routing.RequestContext, ByVal controllerName As String) As ICommand Implements ICommandFactory.CreateController
        If requestContext Is Nothing Then
            Throw New ArgumentNullException("requestContext")
        End If
        If String.IsNullOrEmpty(controllerName) Then
            Throw New ArgumentException("CommandName Invalido", "controllerName")
        End If


    End Function

    Public Sub ReleaseCommand(ByVal command As ICommand) Implements ICommandFactory.ReleaseCommand

    End Sub
End Class
