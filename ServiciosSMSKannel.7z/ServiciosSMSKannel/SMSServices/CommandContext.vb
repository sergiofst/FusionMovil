﻿Imports System.Web.Routing

Public Class CommandContext
    Private m_httpContext As HttpContextBase
    Private m_requestContext As RequestContext
    Private m_controller As CommandBase
    Private m_routeData As RouteData

    Public Sub New(ByVal controllerContext As CommandContext)
        If controllerContext Is Nothing Then
            Throw New ArgumentNullException("controllerContext")
        End If

        Controller = controllerContext.Controller
        RequestContext = controllerContext.RequestContext
    End Sub

    Public Sub New(ByVal httpContext As HttpContextBase, ByVal routeData As RouteData, ByVal controller As CommandBase)
        Me.New(New RequestContext(httpContext, routeData), controller)
    End Sub

    Public Sub New(ByVal request As RequestContext, ByVal controller As CommandBase)
        If RequestContext Is Nothing Then
            Throw New ArgumentNullException("requestContext")
        End If
        If controller Is Nothing Then
            Throw New ArgumentNullException("controller")
        End If
        m_requestContext = request
        m_controller = controller
    End Sub

    Public Property Controller As CommandBase
        Get
            Return m_controller
        End Get
        Set(ByVal value As CommandBase)
            m_controller = value
        End Set
    End Property

    Public Property HttpContext As HttpContextBase
        Get
            If m_httpContext Is Nothing Then
                m_httpContext = New EmptyHttpContext
            End If
            Return m_httpContext
        End Get
        Set(ByVal value As HttpContextBase)
            m_httpContext = value
        End Set
    End Property

    Public Property RouteData As RouteData
        Get
            If m_routeData Is Nothing Then
                m_routeData = CType(IIf(m_requestContext IsNot Nothing, m_requestContext.RouteData, New RouteData()), Routing.RouteData)
            End If
            Return m_routeData
        End Get
        Set(ByVal value As RouteData)
            m_routeData = value
        End Set
    End Property

    Public Property RequestContext As RequestContext
        Get
            Dim tmpHttpContext As HttpContextBase = CType(IIf(HttpContext Is Nothing, New EmptyHttpContext(), HttpContext), HttpContextBase)
            Dim tmpRouteData As RouteData = CType(IIf(RouteData Is Nothing, New RouteData, RouteData), Routing.RouteData)
            m_requestContext = New RequestContext(tmpHttpContext, tmpRouteData)
            Return m_requestContext
        End Get
        Set(ByVal value As RequestContext)
            m_requestContext = value
        End Set
    End Property

    Private Class EmptyHttpContext
        Inherits HttpContextBase
    End Class

End Class
