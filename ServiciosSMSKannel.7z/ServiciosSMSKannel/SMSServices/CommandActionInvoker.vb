﻿Imports System.Threading

Public Class CommandActionInvoker
    Implements IActionInvoker


    Public Overridable Function InvokeAction(ByVal controllerContext As CommandContext, ByVal actionName As String) As Boolean Implements IActionInvoker.InvokeAction
        If controllerContext Is Nothing Then
            Throw New ArgumentNullException("controllerContext")
        End If
        If String.IsNullOrEmpty(actionName) Then
            Throw New ArgumentException("Esta vacio o nulo", "actionName")
        End If

        Dim controllerDescriptor As ControllerDescriptor = GetControllerDescriptor(controllerContext)
        Dim actionDescriptor As ActionDescriptor = FindAction(controllerContext, controllerDescriptor, actionName)
        If actionDescriptor IsNot Nothing Then
            Dim filterInfo As FilterInfo = GetFilters(controllerContext, actionDescriptor)

            Try
                Dim authContext As AuthorizationContext = InvokeAuthorizationFilters(controllerContext, filterInfo.AuthorizationFilters, actionDescriptor)
                If authContext.Result IsNot Nothing Then
                    ' the auth filter signaled that we should let it short-circuit the request
                    InvokeActionResult(controllerContext, authContext.Result)
                Else
                    If controllerContext.Controller.ValidateRequest Then
                        ValidateRequest(controllerContext)
                    End If

                    Dim parameters As IDictionary(Of String, Object) = GetParameterValues(controllerContext, actionDescriptor)
                    Dim postActionContext As ActionExecutedContext = InvokeActionMethodWithFilters(controllerContext, filterInfo.ActionFilters, actionDescriptor, parameters)
                    InvokeActionResultWithFilters(controllerContext, filterInfo.ResultFilters, postActionContext.Result)
                End If
            Catch generatedExceptionName As ThreadAbortException
                ' This type of exception occurs as a result of Response.Redirect(), but we special-case so that
                ' the filters don't see this as an error.
                Throw
            Catch ex As Exception
                ' something blew up, so execute the exception filters
                Dim exceptionContext As ExceptionContext = InvokeExceptionFilters(controllerContext, filterInfo.ExceptionFilters, ex)
                If Not exceptionContext.ExceptionHandled Then
                    Throw
                End If
                InvokeActionResult(controllerContext, exceptionContext.Result)
            End Try

            Return True
        End If

        ' notify controller that no method matched
        Return False
    End Function


End Class
