﻿Imports System.Web.Routing

Public MustInherit Class CommandBase
    Implements ICommand

    Private m_controllerContext As CommandContext

    Protected Sub _Execute(ByVal context As System.Web.Routing.RequestContext) Implements ICommand._Execute
        If context Is Nothing Then
            Throw New ArgumentNullException("RequestContext")
        End If

        Initialize(context)
        ExecuteCore()
    End Sub

    Protected MustOverride Sub ExecuteCore()

    Protected Sub Initialize(ByVal context As RequestContext)
        CommandContext = New CommandContext(context, Me)
    End Sub

    Public Property CommandContext As CommandContext
        Get
            Return m_controllerContext
        End Get
        Set(ByVal value As CommandContext)
            m_controllerContext = value
        End Set
    End Property

End Class
