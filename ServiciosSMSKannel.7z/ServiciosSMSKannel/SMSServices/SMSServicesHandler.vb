﻿Imports System.Web
Imports System.Reflection
Imports System.Web.Routing

Public Class SMSServicesHandler
    Implements IHttpHandler

    Private Shared MvcVersion As String = GetVersionString()
    Private Shared VersionHeaderName As String = "X-FusionMovilSMSServices-Version"

    Private m_requestContext As RequestContext
    Private m_commandBuilder As CommandBuilder

    Public ReadOnly Property IsReusable() As Boolean Implements IHttpHandler.IsReusable
        Get
            ' Return false in case your Managed Handler cannot be reused for another request.
            ' Usually this would be false in case you have some state information preserved per request.
            Return True
        End Get
    End Property

    Public Sub ProcessRequest(ByVal context As HttpContext) Implements IHttpHandler.ProcessRequest
        ' Write your handler implementation here.
        Dim iHttpContext As HttpContextBase = New HttpContextWrapper(context)
        ProcessRequest(iHttpContext)
    End Sub

    Public Sub ProcessRequest(ByVal context As HttpContextBase)
        Dim command As ICommand = Nothing
        Dim factory As ICommandFactory = Nothing
        ProcessRequestInit(context, command, factory)
        Try
            command._Execute(RequestContext)
        Finally
            factory.ReleaseCommand(command)
        End Try
    End Sub

    Public Sub ProcessRequestInit(ByVal httpContext As HttpContextBase, ByRef command As ICommand, ByRef factory As ICommandFactory)
        AddVersionHeader(httpContext)

        ' Busca el controlador
        ' Busco el controlador a partir del texto 
        Dim controllerName As String = ""

        factory = CommandBuilder.GetCommandFactory()
        command = factory.CreateController(RequestContext, controllerName)

        If command Is Nothing Then
            Throw New InvalidOperationException(String.Format("Factory: {0} Command: {1} not found", factory.GetType(), controllerName))
        End If
    End Sub

    Public Property RequestContext As RequestContext
        Get
            Return m_requestContext
        End Get
        Set(ByVal value As RequestContext)
            m_requestContext = value
        End Set
    End Property

    Private Property CommandBuilder As CommandBuilder
        Get
            If m_commandBuilder Is Nothing Then
                m_commandBuilder = CommandBuilder.Current
            End If
            Return m_commandBuilder
        End Get
        Set(ByVal value As CommandBuilder)
            m_commandBuilder = value
        End Set
    End Property

    Private Sub AddVersionHeader(ByVal httpContext As HttpContextBase)
        httpContext.Response.AppendHeader(VersionHeaderName, MvcVersion)
    End Sub

    Public Shared Function GetVersionString() As String
        Return New AssemblyName(GetType(SMSServicesHandler).Assembly.FullName).Version.ToString(2)
    End Function

End Class
