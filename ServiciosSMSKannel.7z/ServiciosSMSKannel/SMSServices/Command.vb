﻿Imports System.Web.Routing

Public MustInherit Class Command
    Inherits CommandBase

    Private m_actionInvoker As IActionInvoker

    Public MustOverride Function Execute(ByVal context As CommandContext) As ActionResult

    Protected Overrides Sub ExecuteCore()
        Try
            Dim result As ActionResult = Execute(CommandContext)
            result.ExecuteResult(CommandContext)
        Catch ex As Exception
            Throw New HttpException(501, "Error al ejecutar el comando")
        End Try
    End Sub

    Public ReadOnly Property RouteData As RouteData
        Get
            Return CType(IIf(CommandContext Is Nothing, Nothing, CommandContext.RouteData), Routing.RouteData)
        End Get
    End Property

    Public ReadOnly Property HttpContext As HttpContextBase
        Get
            Return CType(IIf(CommandContext Is Nothing, Nothing, CommandContext.HttpContext), HttpContextBase)
        End Get
    End Property

    Public ReadOnly Property Server As HttpServerUtilityBase
        Get
            Return CType(IIf(HttpContext Is Nothing, Nothing, HttpContext.Server), HttpServerUtilityBase)
        End Get
    End Property

    Public ReadOnly Property Session As HttpSessionStateBase
        Get
            Return CType(IIf(HttpContext Is Nothing, Nothing, HttpContext.Session), HttpSessionStateBase)
        End Get
    End Property

    Public ReadOnly Property Request As HttpRequestBase
        Get
            Return CType(IIf(HttpContext Is Nothing, Nothing, HttpContext.Request), HttpRequestBase)
        End Get
    End Property

    Public ReadOnly Property Response As HttpResponseBase
        Get
            Return CType(IIf(HttpContext Is Nothing, Nothing, HttpContext.Response), HttpResponseBase)
        End Get
    End Property

    'Public Property ActionInvoker As IActionInvoker
    '    Get
    '        If m_actionInvoker Is Nothing Then
    '            m_actionInvoker = CreateActionInvoker()
    '        End If
    '        Return m_actionInvoker
    '    End Get
    '    Set(ByVal value As IActionInvoker)
    '        m_actionInvoker = value
    '    End Set
    'End Property

    'Protected Function CreateActionInvoker() As IActionInvoker
    '    Return New CommandActionInvoker()
    'End Function


End Class
