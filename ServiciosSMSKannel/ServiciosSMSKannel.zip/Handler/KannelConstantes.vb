﻿Public Class KannelConstantes
    Public Const [TO] As String = "to"
    Public Const FROM As String = "from"
    Public Const TEXTO As String = "text"
    Public Const SMSC As String = "smsc"
    Public Const USER_NAME As String = "username"
    Public Const PASSWORD As String = "password"
    Public Const CCLAVE As String = "clave"
End Class
