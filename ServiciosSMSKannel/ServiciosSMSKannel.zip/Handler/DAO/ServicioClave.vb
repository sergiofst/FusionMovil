﻿Public Class ServicioClave
    Public IdServicioClave As Integer
    Public IdServicio As Integer
    Public Clave As String
    Public Estatus As Integer

End Class
