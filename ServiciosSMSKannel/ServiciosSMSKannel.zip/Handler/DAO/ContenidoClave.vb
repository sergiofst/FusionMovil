﻿Public Class ContenidoClave
    Public IdContenidoClave As Integer
    Public IdContenido As Integer
    Public Clave As String
    Public Estatus As Integer
    Public IdMedio As Integer
End Class
