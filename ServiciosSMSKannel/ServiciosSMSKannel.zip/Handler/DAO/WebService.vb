﻿Public Class WebService
    Public userId As String
    Public Password As String
    Public userTransactionId As String
    Public RatingId As Integer
    Public msisdn As String
    Public Idcontenido As String
    Public NombreContenido As String
    Public urlOk As String
    Public urlCancel As String
    Public urlError As String
    Public urlUnsusc As String
    Public ExtraParam As String
End Class
