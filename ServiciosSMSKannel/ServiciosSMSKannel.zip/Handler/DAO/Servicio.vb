﻿Public Class Servicio
    Public IdServicio As Integer
    Public Nombre As String
    Public Clase As String
    Public Estatus As Integer
    Public SRSRatingId As Integer
End Class
