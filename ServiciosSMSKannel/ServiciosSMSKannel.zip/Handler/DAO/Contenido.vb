﻿Public Class Contenido
    Public IdContenido As Integer
    Public IdServicio As Integer
    Public Nombre As String
    Public Archivo As String
    Public Icono As String
    Public IconoDestacado As String
    Public Estatus As Integer
    Public Texto As String
End Class
