﻿Imports System.Web.Routing

Public Interface ICommand
    Sub _Execute(ByVal httpContext As HttpContextBase)
End Interface
